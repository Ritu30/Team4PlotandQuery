﻿
Partial Class Default2
    Inherits System.Web.UI.Page

End Class
